# Wykop Player Remover

Skrypt + plugin (Firefox) do usuwania jwplayera z wykop.pl

https://addons.mozilla.org/pl/firefox/addon/wykop-player-remover/